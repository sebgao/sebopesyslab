head -c 512 disk.bin | hd
