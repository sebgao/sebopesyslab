#ifndef _RND_H
#define _RND_H
unsigned int UKISS();
#endif